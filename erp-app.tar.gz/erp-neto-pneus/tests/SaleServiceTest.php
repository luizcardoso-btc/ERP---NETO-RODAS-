<?php
declare(strict_types=1);

use App\Database;
use App\SaleService;
use PHPUnit\Framework\TestCase;

final class SaleServiceTest extends TestCase
{
    private int $pid;

    protected function setUp(): void
    {
        $pdo = Database::pdo();
        $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
        foreach (['stock_movements', 'accounts_receivable', 'sale_payments', 'sale_items', 'sales', 'products', 'customers', 'sellers'] as $t) {
            $pdo->exec("TRUNCATE TABLE $t");
        }
        $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
        $this->pid = Database::insert("INSERT INTO products (name, cost_price, price, stock) VALUES ('Pneu 175/70 R14', 200, 300, 10)");
    }

    private function sale(array $over = []): array
    {
        return array_replace([
            'request_token' => uuid4(),
            'items' => [['product_id' => $this->pid, 'quantity' => 2, 'unit_price' => 300.0]],
            'payments' => [['method' => 'pix', 'amount' => 600.0]],
        ], $over);
    }

    public function testSaleDecrementsStockAndRecordsCostSnapshot(): void
    {
        $r = SaleService::create($this->sale());
        $this->assertFalse($r['duplicate']);
        $this->assertSame(8, (int) Database::value('SELECT stock FROM products WHERE id = ?', [$this->pid]));
        $this->assertSame(200.0, (float) Database::value('SELECT unit_cost FROM sale_items WHERE sale_id = ?', [$r['id']]));
        $this->assertSame(-2, (int) Database::value("SELECT quantity FROM stock_movements WHERE sale_id = ? AND type = 'out'", [$r['id']]));
    }

    public function testSameTokenIsIdempotent(): void
    {
        $data = $this->sale();
        $a = SaleService::create($data);
        $b = SaleService::create($data);
        $this->assertTrue($b['duplicate']);
        $this->assertSame($a['id'], $b['id']);
        $this->assertSame(8, (int) Database::value('SELECT stock FROM products WHERE id = ?', [$this->pid]));
        $this->assertSame(1, (int) Database::value('SELECT COUNT(*) FROM sales'));
    }

    public function testPaymentsMustMatchTotal(): void
    {
        $this->expectException(DomainException::class);
        SaleService::create($this->sale(['payments' => [['method' => 'pix', 'amount' => 500.0]]]));
    }

    public function testInsufficientStockRollsBackEverything(): void
    {
        try {
            SaleService::create($this->sale(['items' => [['product_id' => $this->pid, 'quantity' => 11, 'unit_price' => 300.0]], 'payments' => [['method' => 'pix', 'amount' => 3300.0]]]));
            $this->fail('Deveria recusar estoque insuficiente');
        } catch (DomainException $e) {
            $this->assertStringContainsString('Estoque insuficiente', $e->getMessage());
        }
        $this->assertSame(0, (int) Database::value('SELECT COUNT(*) FROM sales'));
        $this->assertSame(10, (int) Database::value('SELECT stock FROM products WHERE id = ?', [$this->pid]));
    }

    public function testSplitPaymentWithTradeInCreatesUsedStockAndReceivable(): void
    {
        $r = SaleService::create($this->sale([
            'due_date' => '2026-12-01',
            'payments' => [
                ['method' => 'pix', 'amount' => 200.0],
                ['method' => 'troca', 'amount' => 200.0, 'note' => '2 pneus 175/70 usados', 'trade_qty' => 2],
                ['method' => 'prazo', 'amount' => 200.0],
            ],
        ]));
        $used = Database::one("SELECT * FROM products WHERE condition_type = 'usado'");
        $this->assertSame(2, (int) $used['stock']);
        $this->assertSame(100.0, (float) $used['cost_price']);
        $ar = Database::one('SELECT * FROM accounts_receivable WHERE sale_id = ?', [$r['id']]);
        $this->assertSame(200.0, (float) $ar['amount']);
        $this->assertSame('2026-12-01', $ar['due_date']);
        $this->assertSame('pending', Database::value('SELECT payment_status FROM sales WHERE id = ?', [$r['id']]));
    }

    public function testNfeRequiresAddressAndTaxId(): void
    {
        $this->expectException(DomainException::class);
        $this->expectExceptionMessageMatches('/CPF\/CNPJ.*logradouro/');
        SaleService::create($this->sale(['wants_nfe' => true, 'customer' => ['first_name' => 'Ana']]));
    }

    public function testNewCustomerAndNewProductAreCreatedInline(): void
    {
        $r = SaleService::create($this->sale([
            'customer' => ['first_name' => 'Rogerio', 'phone' => '75999922002', 'car' => 'Onix'],
            'items' => [['name' => 'Alinhamento', 'quantity' => 1, 'unit_price' => 80.0]],
            'payments' => [['method' => 'dinheiro', 'amount' => 80.0]],
        ]));
        $this->assertSame('Rogerio', Database::value('SELECT c.first_name FROM sales s JOIN customers c ON c.id = s.customer_id WHERE s.id = ?', [$r['id']]));
        $this->assertSame(1, (int) Database::value("SELECT COUNT(*) FROM products WHERE name = 'Alinhamento'"));
        // Mesmo telefone reaproveita o cliente em vez de duplicar.
        SaleService::create($this->sale(['customer' => ['first_name' => 'Rogerio', 'phone' => '75 99992-2002']]));
        $this->assertSame(1, (int) Database::value('SELECT COUNT(*) FROM customers'));
    }
}

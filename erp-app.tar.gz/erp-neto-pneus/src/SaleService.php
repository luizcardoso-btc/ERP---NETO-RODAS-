<?php
declare(strict_types=1);

namespace App;

use DomainException;
use PDOException;

/**
 * Regras de venda: itens, pagamentos multiplos, troca, estoque e contas a receber.
 * Tudo acontece numa unica transacao; vendas repetidas (mesmo request_token) sao ignoradas.
 */
final class SaleService
{
    public const METHODS = ['dinheiro', 'pix', 'cartao', 'prazo', 'troca'];
    public const ADDRESS_FIELDS = ['street' => 'logradouro', 'number' => 'numero', 'district' => 'bairro', 'city' => 'cidade', 'state' => 'UF', 'zip' => 'CEP'];

    /**
     * @param array{
     *   request_token:string, seller_id?:?int, wants_nfe?:bool, notes?:?string, due_date?:?string,
     *   customer?:?array<string,mixed>,
     *   items:list<array{product_id?:?int,name?:string,quantity:int,unit_price:float}>,
     *   payments:list<array{method:string,amount:float,note?:?string,trade_qty?:int}>
     * } $data
     * @return array{id:int,duplicate:bool}
     */
    public static function create(array $data, string $source = 'pdv', bool $allowNegativeStock = false): array
    {
        $token = trim((string) ($data['request_token'] ?? ''));
        if (!preg_match('/^[0-9a-f-]{36}$/i', $token)) {
            throw new DomainException('Requisicao invalida. Recarregue a pagina e tente de novo.');
        }
        if ($existing = Database::value('SELECT id FROM sales WHERE request_token = ?', [$token])) {
            return ['id' => (int) $existing, 'duplicate' => true];
        }

        $items = self::normalizeItems($data['items'] ?? []);
        $totalCents = array_sum(array_map(fn ($i) => (int) round($i['unit_price'] * 100) * $i['quantity'], $items));
        $payments = self::normalizePayments($data['payments'] ?? []);
        $paidCents = array_sum(array_map(fn ($p) => (int) round($p['amount'] * 100), $payments));
        if ($paidCents !== $totalCents) {
            throw new DomainException(sprintf(
                'Os pagamentos (%s) precisam fechar com o total da venda (%s).',
                money($paidCents / 100),
                money($totalCents / 100)
            ));
        }

        $customerIn = $data['customer'] ?? null;
        if (!empty($data['wants_nfe'])) {
            self::assertNfeCustomer($customerIn);
        }

        $pdo = Database::pdo();
        $pdo->beginTransaction();
        try {
            $customerId = self::resolveCustomer($customerIn);
            $sellerId = !empty($data['seller_id']) ? (int) $data['seller_id'] : null;
            $prazoCents = array_sum(array_map(
                fn ($p) => $p['method'] === 'prazo' ? (int) round($p['amount'] * 100) : 0,
                $payments
            ));

            $saleId = Database::insert(
                'INSERT INTO sales (request_token, customer_id, seller_id, total, payment_status, source, wants_nfe, notes)
                 VALUES (?,?,?,?,?,?,?,?)',
                [
                    $token, $customerId, $sellerId, $totalCents / 100,
                    $prazoCents > 0 ? 'pending' : 'paid', $source,
                    empty($data['wants_nfe']) ? 0 : 1,
                    self::clip($data['notes'] ?? null, 255),
                ]
            );

            foreach ($items as $item) {
                self::addItem($saleId, $item, $allowNegativeStock);
            }

            foreach ($payments as $p) {
                Database::insert(
                    'INSERT INTO sale_payments (sale_id, method, amount, note) VALUES (?,?,?,?)',
                    [$saleId, $p['method'], $p['amount'], $p['note']]
                );
                if ($p['method'] === 'troca') {
                    self::receiveTradeIn($saleId, $p);
                }
            }

            if ($prazoCents > 0) {
                $due = self::validDate($data['due_date'] ?? null) ?? date('Y-m-d', strtotime('+30 days'));
                Database::insert(
                    'INSERT INTO accounts_receivable (sale_id, customer_id, description, amount, due_date) VALUES (?,?,?,?,?)',
                    [$saleId, $customerId, "Venda #$saleId (parte a prazo)", $prazoCents / 100, $due]
                );
            }

            $pdo->commit();
            return ['id' => $saleId, 'duplicate' => false];
        } catch (PDOException $e) {
            $pdo->rollBack();
            // Duas requisicoes simultaneas com o mesmo token: a segunda cai aqui.
            if ($e->getCode() === '23000' && ($id = Database::value('SELECT id FROM sales WHERE request_token = ?', [$token]))) {
                return ['id' => (int) $id, 'duplicate' => true];
            }
            throw $e;
        } catch (\Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    /** @return list<array{product_id:?int,name:string,quantity:int,unit_price:float}> */
    public static function normalizeItems(array $rows): array
    {
        $out = [];
        foreach ($rows as $r) {
            $name = trim((string) ($r['name'] ?? ''));
            $pid = !empty($r['product_id']) ? (int) $r['product_id'] : null;
            $qty = (int) ($r['quantity'] ?? 0);
            $price = round((float) ($r['unit_price'] ?? 0), 2);
            if ($pid === null && $name === '') {
                continue; // linha vazia
            }
            if ($qty < 1) {
                throw new DomainException('Informe a quantidade de cada item (minimo 1).');
            }
            if ($price < 0) {
                throw new DomainException('Preco unitario nao pode ser negativo.');
            }
            $out[] = ['product_id' => $pid, 'name' => $name, 'quantity' => $qty, 'unit_price' => $price];
        }
        if (!$out) {
            throw new DomainException('Adicione ao menos um item na venda.');
        }
        return $out;
    }

    /** @return list<array{method:string,amount:float,note:?string,trade_qty:int}> */
    public static function normalizePayments(array $rows): array
    {
        $out = [];
        foreach ($rows as $r) {
            $method = (string) ($r['method'] ?? '');
            $amount = round((float) ($r['amount'] ?? 0), 2);
            if ($amount <= 0) {
                continue;
            }
            if (!in_array($method, self::METHODS, true)) {
                throw new DomainException('Forma de pagamento invalida.');
            }
            $note = self::clip($r['note'] ?? null, 200);
            if ($method === 'troca' && ($note === null || $note === '')) {
                throw new DomainException('Na troca, descreva o item recebido.');
            }
            $out[] = ['method' => $method, 'amount' => $amount, 'note' => $note, 'trade_qty' => max(1, (int) ($r['trade_qty'] ?? 1))];
        }
        if (!$out) {
            throw new DomainException('Informe como o cliente pagou.');
        }
        return $out;
    }

    private static function assertNfeCustomer(?array $c): void
    {
        $missing = [];
        if (!$c || digits($c['tax_id'] ?? '') === '') {
            $missing[] = 'CPF/CNPJ';
        }
        foreach (self::ADDRESS_FIELDS as $key => $label) {
            if (!$c || trim((string) ($c[$key] ?? '')) === '') {
                $missing[] = $label;
            }
        }
        if ($missing) {
            throw new DomainException('Para emitir NF-e, preencha: ' . implode(', ', $missing) . '.');
        }
    }

    private static function resolveCustomer(?array $c): ?int
    {
        if (!$c) {
            return null;
        }
        $fields = ['first_name', 'last_name', 'email', 'phone', 'tax_id', 'car', 'street', 'number', 'district', 'city', 'state', 'zip', 'notes'];
        $clean = [];
        foreach ($fields as $f) {
            $clean[$f] = trim((string) ($c[$f] ?? ''));
        }
        $clean['tax_id'] = digits($clean['tax_id']);
        $clean['phone'] = format_phone($clean['phone']);
        $clean['state'] = strtoupper(substr($clean['state'], 0, 2));

        $id = !empty($c['customer_id']) ? (int) $c['customer_id'] : null;
        if (!$id && $clean['tax_id'] !== '') {
            $id = Database::value('SELECT id FROM customers WHERE tax_id = ? LIMIT 1', [$clean['tax_id']]) ?: null;
        }
        if (!$id && digits($clean['phone']) !== '') {
            $id = Database::value('SELECT id FROM customers WHERE phone = ? LIMIT 1', [$clean['phone']]) ?: null;
        }

        if ($id) {
            // Atualiza apenas o que foi preenchido, sem apagar dados existentes.
            $sets = [];
            $vals = [];
            foreach ($clean as $f => $v) {
                if ($v !== '' && $f !== 'first_name' && $f !== 'last_name') {
                    $sets[] = "$f = ?";
                    $vals[] = $v;
                }
            }
            if ($sets) {
                $vals[] = $id;
                Database::run('UPDATE customers SET ' . implode(', ', $sets) . ' WHERE id = ?', $vals);
            }
            return (int) $id;
        }

        if ($clean['first_name'] === '') {
            return null; // venda sem cliente identificado
        }
        $cols = array_keys($clean);
        return Database::insert(
            'INSERT INTO customers (' . implode(',', $cols) . ') VALUES (' . implode(',', array_fill(0, count($cols), '?')) . ')',
            array_map(fn ($k, $v) => $v === '' && $k !== 'last_name' ? null : $v, array_keys($clean), array_values($clean))
        );
    }

    private static function addItem(int $saleId, array $item, bool $allowNegative): void
    {
        $created = false;
        if ($item['product_id']) {
            $p = Database::one('SELECT id, name, cost_price, stock FROM products WHERE id = ? FOR UPDATE', [$item['product_id']]);
            if (!$p) {
                throw new DomainException('Produto nao encontrado.');
            }
        } else {
            $pid = Database::insert(
                'INSERT INTO products (name, price, cost_price, stock) VALUES (?,?,0,0)',
                [self::clip($item['name'], 200), $item['unit_price']]
            );
            $p = ['id' => $pid, 'name' => $item['name'], 'cost_price' => 0, 'stock' => 0];
            $created = true;
        }

        if (!$created && !$allowNegative && (int) $p['stock'] < $item['quantity']) {
            throw new DomainException(sprintf(
                'Estoque insuficiente de "%s": disponivel %d, pedido %d.',
                $p['name'],
                (int) $p['stock'],
                $item['quantity']
            ));
        }

        Database::insert(
            'INSERT INTO sale_items (sale_id, product_id, description, quantity, unit_price, unit_cost) VALUES (?,?,?,?,?,?)',
            [$saleId, $p['id'], self::clip($p['name'], 200), $item['quantity'], $item['unit_price'], $p['cost_price']]
        );
        Database::run('UPDATE products SET stock = stock - ? WHERE id = ?', [$item['quantity'], $p['id']]);
        Database::insert(
            'INSERT INTO stock_movements (product_id, type, quantity, reason, sale_id) VALUES (?,?,?,?,?)',
            [$p['id'], 'out', -$item['quantity'], "Venda #$saleId", $saleId]
        );
    }

    /** Item recebido em troca entra no estoque como usado, com custo = valor creditado. */
    private static function receiveTradeIn(int $saleId, array $p): void
    {
        $qty = $p['trade_qty'];
        $unit = round($p['amount'] / $qty, 2);
        $pid = Database::insert(
            "INSERT INTO products (name, condition_type, cost_price, price, stock, category) VALUES (?, 'usado', ?, ?, ?, 'pneu')",
            [self::clip($p['note'], 200), $unit, $unit, $qty]
        );
        Database::insert(
            'INSERT INTO stock_movements (product_id, type, quantity, reason, sale_id) VALUES (?,?,?,?,?)',
            [$pid, 'in', $qty, "Troca na venda #$saleId", $saleId]
        );
    }

    private static function clip(?string $v, int $max): ?string
    {
        $v = trim((string) $v);
        return $v === '' ? null : mb_substr($v, 0, $max);
    }

    private static function validDate(?string $v): ?string
    {
        if (!$v || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $v)) {
            return null;
        }
        [$y, $m, $d] = array_map('intval', explode('-', $v));
        return checkdate($m, $d, $y) ? $v : null;
    }
}

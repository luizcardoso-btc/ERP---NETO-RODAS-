<?php
declare(strict_types=1);

namespace App;

use PDO;

final class Database
{
    private static ?PDO $pdo = null;

    /** Descobre as credenciais: DB_* tem prioridade, depois MYSQL_URL/DATABASE_URL, depois MYSQLHOST etc. (Railway). */
    public static function config(): array
    {
        $c = [
            'host' => Env::get('DB_HOST'), 'port' => Env::get('DB_PORT'), 'name' => Env::get('DB_NAME'),
            'user' => Env::get('DB_USER'), 'pass' => Env::get('DB_PASS'),
        ];
        $url = Env::get('MYSQL_URL') ?? Env::get('DATABASE_URL');
        if ($url && ($u = parse_url($url)) && !empty($u['host'])) {
            $c['host'] ??= $u['host'];
            $c['port'] ??= (string) ($u['port'] ?? 3306);
            $c['name'] ??= ltrim($u['path'] ?? '', '/');
            $c['user'] ??= urldecode($u['user'] ?? '');
            $c['pass'] ??= urldecode($u['pass'] ?? '');
        }
        $c['host'] ??= Env::get('MYSQLHOST');
        $c['port'] ??= Env::get('MYSQLPORT');
        $c['name'] ??= Env::get('MYSQLDATABASE');
        $c['user'] ??= Env::get('MYSQLUSER');
        $c['pass'] ??= Env::get('MYSQLPASSWORD');

        return [
            'host' => $c['host'] ?? '127.0.0.1', 'port' => $c['port'] ?? '3306', 'name' => $c['name'] ?? 'erp',
            'user' => $c['user'] ?? 'root', 'pass' => $c['pass'] ?? '',
        ];
    }

    /** True quando alguma configuracao de banco foi fornecida (nao apenas os padroes locais). */
    public static function isConfigured(): bool
    {
        foreach (['DB_HOST', 'MYSQL_URL', 'DATABASE_URL', 'MYSQLHOST'] as $k) {
            if (Env::get($k)) {
                return true;
            }
        }
        return false;
    }

    public static function pdo(): PDO
    {
        if (self::$pdo === null) {
            $c = self::config();
            $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4', $c['host'], $c['port'], $c['name']);
            self::$pdo = new PDO($dsn, $c['user'], $c['pass'], [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_TIMEOUT => 5,
            ]);
        }
        return self::$pdo;
    }

    public static function use(PDO $pdo): void
    {
        self::$pdo = $pdo;
    }

    public static function all(string $sql, array $params = []): array
    {
        $st = self::pdo()->prepare($sql);
        $st->execute($params);
        return $st->fetchAll();
    }

    public static function one(string $sql, array $params = []): ?array
    {
        $st = self::pdo()->prepare($sql);
        $st->execute($params);
        $row = $st->fetch();
        return $row ?: null;
    }

    public static function value(string $sql, array $params = []): mixed
    {
        $st = self::pdo()->prepare($sql);
        $st->execute($params);
        $v = $st->fetchColumn();
        return $v === false ? null : $v;
    }

    public static function run(string $sql, array $params = []): int
    {
        $st = self::pdo()->prepare($sql);
        $st->execute($params);
        return $st->rowCount();
    }

    public static function insert(string $sql, array $params = []): int
    {
        self::run($sql, $params);
        return (int) self::pdo()->lastInsertId();
    }
}

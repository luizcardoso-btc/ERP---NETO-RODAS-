<?php
declare(strict_types=1);

namespace App;

/** Busca rapida (JSON) de produtos e clientes para o PDV. */
final class Lookup
{
    public static function respond(): void
    {
        $kind = (string) ($_GET['lookup'] ?? '');
        $q = trim((string) ($_GET['q'] ?? ''));
        header('Content-Type: application/json; charset=utf-8');
        if (mb_strlen($q) < 2) {
            echo '[]';
            exit;
        }
        $like = '%' . addcslashes($q, '%_\\') . '%';
        if ($kind === 'product') {
            $rows = Database::all(
                "SELECT id, name, price, stock, condition_type, location FROM products
                 WHERE active = 1 AND (name LIKE ? OR brand LIKE ? OR model LIKE ? OR gtin LIKE ? OR mpn LIKE ?
                       OR CONCAT_WS('/', width, profile) LIKE ? OR compatible_cars LIKE ?)
                 ORDER BY (stock > 0) DESC, name LIMIT 12",
                [$like, $like, $like, $like, $like, $like, $like]
            );
        } elseif ($kind === 'customer') {
            $d = digits($q);
            $rows = Database::all(
                "SELECT id, first_name, last_name, email, phone, tax_id, car, street, number, district, city, state, zip, country
                 FROM customers
                 WHERE CONCAT_WS(' ', first_name, last_name) LIKE ? OR car LIKE ? OR email LIKE ?
                    " . ($d !== '' ? 'OR REPLACE(REPLACE(REPLACE(phone,\' \',\'\'),\'-\',\'\'),\'(\',\'\') LIKE ? OR tax_id LIKE ?' : '') . '
                 ORDER BY first_name LIMIT 8',
                $d !== '' ? [$like, $like, $like, '%' . $d . '%', '%' . $d . '%'] : [$like, $like, $like]
            );
        } else {
            $rows = [];
        }
        echo json_encode($rows, JSON_UNESCAPED_UNICODE);
        exit;
    }
}

<?php
use App\Database;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'create') {
        $name = trim((string) ($_POST['name'] ?? ''));
        if ($name === '') {
            flash('err', 'Informe o nome do vendedor.');
        } else {
            Database::insert(
                'INSERT INTO sellers (name, weekly_pay, access_token, color) VALUES (?,?,?,?)',
                [$name, parse_money($_POST['weekly_pay'] ?? 0), bin2hex(random_bytes(20)), preg_match('/^#[0-9a-f]{6}$/i', $_POST['color'] ?? '') ? $_POST['color'] : '#10b981']
            );
            flash('ok', "Vendedor $name cadastrado.");
        }
    } elseif ($action === 'update') {
        Database::run(
            'UPDATE sellers SET name = ?, weekly_pay = ?, active = ? WHERE id = ?',
            [trim((string) $_POST['name']), parse_money($_POST['weekly_pay'] ?? 0), empty($_POST['active']) ? 0 : 1, (int) $_POST['id']]
        );
        flash('ok', 'Vendedor atualizado.');
    } elseif ($action === 'new_token') {
        Database::run('UPDATE sellers SET access_token = ? WHERE id = ?', [bin2hex(random_bytes(20)), (int) $_POST['id']]);
        flash('ok', 'Novo link gerado. O link antigo deixou de funcionar.');
    }
    redirect(url('vendedores'));
}

$sellers = Database::all('SELECT * FROM sellers ORDER BY active DESC, name');
$base = (is_https() ? 'https' : 'http') . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost') . rtrim(dirname($_SERVER['SCRIPT_NAME']), '/');
?>
<section class="hero slim"><div><h1>Vendedores</h1><p>Cada vendedor tem um link pessoal para registrar vendas pelo celular, sem precisar de senha. A folha semanal entra no lucro do dashboard.</p></div></section>
<div class="cols">
  <form class="card" method="post">
    <?= App\Csrf::field() ?><input type="hidden" name="action" value="create">
    <h2>Novo vendedor</h2>
    <div class="stack" style="margin-top:12px">
      <input name="name" placeholder="Nome" required>
      <input name="weekly_pay" placeholder="Pagamento semanal (R$)" inputmode="decimal">
      <div><label class="f" for="color">Cor no grafico</label><input id="color" name="color" type="color" value="#10b981" style="height:44px;padding:4px"></div>
      <button class="btn green" type="submit">Cadastrar</button>
    </div>
  </form>
  <div class="card">
    <h2>Equipe</h2>
    <?php if (!$sellers): ?><p class="muted">Nenhum vendedor ainda. Cadastre o primeiro ao lado.</p><?php endif; ?>
    <?php foreach ($sellers as $s): $link = $base . '/index.php?page=pdv_mobile&t=' . $s['access_token']; ?>
      <form method="post" class="item-line">
        <?= App\Csrf::field() ?><input type="hidden" name="id" value="<?= (int) $s['id'] ?>">
        <div class="grid" style="grid-template-columns:2fr 1fr auto">
          <input name="name" value="<?= e($s['name']) ?>" aria-label="Nome">
          <input name="weekly_pay" value="<?= e(number_format((float) $s['weekly_pay'], 2, ',', '.')) ?>" aria-label="Pagamento semanal">
          <label class="small" style="align-self:center"><input type="checkbox" name="active" value="1" style="width:auto" <?= $s['active'] ? 'checked' : '' ?>> ativo</label>
        </div>
        <div class="line-foot">
          <input readonly value="<?= e($link) ?>" onclick="this.select()" aria-label="Link do PDV mobile" style="max-width:70%;font-size:12px">
          <span class="actions">
            <button class="btn ghost sm" name="action" value="new_token" type="submit" onclick="return confirm('Gerar novo link? O atual para de funcionar.')">Novo link</button>
            <button class="btn sm" name="action" value="update" type="submit">Salvar</button>
          </span>
        </div>
      </form>
    <?php endforeach; ?>
  </div>
</div>

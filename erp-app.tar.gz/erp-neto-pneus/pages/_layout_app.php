<?php
/** @var string $content @var string $title @var string $page */
$nav = array_filter(PAGES, fn ($k) => $k !== 'vendedores' || App\Auth::isAdmin(), ARRAY_FILTER_USE_KEY);
?><!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> - ERP Pneus</title>
<link rel="stylesheet" href="assets/app.css">
</head>
<body>
<div class="shell">
  <aside class="side" id="side">
    <div class="co">NETO RODAS</div>
    <div class="app">ERP Pneus</div>
    <button class="btn ghost sm top-toggle" type="button" onclick="document.getElementById('side').classList.toggle('open')">Menu</button>
    <nav>
      <?php foreach ($nav as $key => $label): ?>
        <a href="<?= e(url($key)) ?>" class="<?= $key === $page ? 'on' : '' ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
    </nav>
    <div class="who">
      <b><?= e(App\Auth::user()['username'] ?? '') ?></b>
      <a href="<?= e(url('logout')) ?>">Sair</a>
    </div>
  </aside>
  <main class="main">
    <?php foreach (take_flashes() as $f): ?>
      <div class="flash <?= $f['type'] === 'ok' ? 'ok' : 'err' ?>" role="status"><?= e($f['message']) ?></div>
    <?php endforeach; ?>
    <?= $content ?>
  </main>
</div>
</body>
</html>

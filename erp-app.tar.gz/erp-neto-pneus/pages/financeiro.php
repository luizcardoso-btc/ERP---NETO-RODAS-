<?php
use App\Database;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $date = preg_match('/^\d{4}-\d{2}-\d{2}$/', $_POST['due_date'] ?? '') ? $_POST['due_date'] : null;
    if ($action === 'add_payable') {
        $amount = parse_money($_POST['amount'] ?? 0);
        $desc = trim((string) ($_POST['description'] ?? ''));
        if ($desc === '' || $amount <= 0) {
            flash('err', 'Informe descricao e valor da conta.');
        } else {
            Database::insert('INSERT INTO accounts_payable (description, category, amount, due_date) VALUES (?,?,?,?)', [mb_substr($desc, 0, 200), trim((string) ($_POST['category'] ?? '')) ?: null, $amount, $date]);
            flash('ok', 'Conta a pagar cadastrada.');
        }
    } elseif ($action === 'add_receivable') {
        $amount = parse_money($_POST['amount'] ?? 0);
        $desc = trim((string) ($_POST['description'] ?? ''));
        if ($desc === '' || $amount <= 0) {
            flash('err', 'Informe descricao e valor do recebimento.');
        } else {
            Database::insert('INSERT INTO accounts_receivable (description, amount, due_date) VALUES (?,?,?)', [mb_substr($desc, 0, 200), $amount, $date]);
            flash('ok', 'Conta a receber cadastrada.');
        }
    } elseif ($action === 'pay' && in_array($_POST['table'] ?? '', ['accounts_payable', 'accounts_receivable'], true)) {
        $t = $_POST['table'];
        Database::run("UPDATE $t SET paid_at = NOW() WHERE id = ? AND paid_at IS NULL", [(int) $_POST['id']]);
        if ($t === 'accounts_receivable' && ($sid = Database::value('SELECT sale_id FROM accounts_receivable WHERE id = ?', [(int) $_POST['id']]))) {
            // Quando todas as parcelas a prazo da venda foram recebidas, a venda passa a paga.
            if (!Database::value('SELECT COUNT(*) FROM accounts_receivable WHERE sale_id = ? AND paid_at IS NULL', [$sid])) {
                Database::run("UPDATE sales SET payment_status = 'paid' WHERE id = ?", [$sid]);
            }
        }
        flash('ok', 'Baixa registrada.');
    } elseif ($action === 'delete' && in_array($_POST['table'] ?? '', ['accounts_payable', 'accounts_receivable'], true)) {
        Database::run('DELETE FROM ' . $_POST['table'] . ' WHERE id = ? AND paid_at IS NULL', [(int) $_POST['id']]);
        flash('ok', 'Lancamento removido.');
    }
    redirect(url('financeiro'));
}

$ar = Database::all("SELECT a.*, CONCAT_WS(' ', c.first_name, c.last_name) customer FROM accounts_receivable a LEFT JOIN customers c ON c.id = a.customer_id ORDER BY (a.paid_at IS NOT NULL), a.due_date IS NULL, a.due_date LIMIT 100");
$ap = Database::all('SELECT * FROM accounts_payable ORDER BY (paid_at IS NOT NULL), due_date IS NULL, due_date LIMIT 100');
$openAr = (float) Database::value('SELECT COALESCE(SUM(amount),0) FROM accounts_receivable WHERE paid_at IS NULL');
$openAp = (float) Database::value('SELECT COALESCE(SUM(amount),0) FROM accounts_payable WHERE paid_at IS NULL');
$lateAr = (float) Database::value('SELECT COALESCE(SUM(amount),0) FROM accounts_receivable WHERE paid_at IS NULL AND due_date < CURDATE()');
$lateAp = (float) Database::value('SELECT COALESCE(SUM(amount),0) FROM accounts_payable WHERE paid_at IS NULL AND due_date < CURDATE()');

function fin_table(array $rows, string $table, bool $hasCustomer): void
{ ?>
  <div class="scroll"><table><thead><tr><th>Descricao</th><th>Vencimento</th><th class="num">Valor</th><th></th></tr></thead><tbody>
  <?php foreach ($rows as $r): $late = !$r['paid_at'] && $r['due_date'] && $r['due_date'] < date('Y-m-d'); ?>
    <tr style="<?= $r['paid_at'] ? 'opacity:.55' : '' ?>"><td><?= e($r['description']) ?><?= $hasCustomer && $r['customer'] ? '<br><span class="small muted">' . e($r['customer']) . '</span>' : '' ?></td>
      <td><?= e(fmt_date($r['due_date'])) ?> <?php if ($r['paid_at']): ?><span class="tag green">pago</span><?php elseif ($late): ?><span class="tag red">atrasado</span><?php endif; ?></td>
      <td class="num"><b><?= money($r['amount']) ?></b></td>
      <td class="actions"><?php if (!$r['paid_at']): ?>
        <form method="post"><?= App\Csrf::field() ?><input type="hidden" name="action" value="pay"><input type="hidden" name="table" value="<?= $table ?>"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn green sm" type="submit">Dar baixa</button></form>
        <form method="post" onsubmit="return confirm('Remover lancamento?')"><?= App\Csrf::field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="table" value="<?= $table ?>"><input type="hidden" name="id" value="<?= (int) $r['id'] ?>"><button class="btn danger sm" type="submit">Remover</button></form>
      <?php endif; ?></td></tr>
  <?php endforeach; ?>
  <?php if (!$rows): ?><tr><td colspan="4" class="muted">Nenhum lancamento.</td></tr><?php endif; ?></tbody></table></div>
<?php } ?>
<section class="hero slim"><div><h1>Financeiro</h1><p>Contas a receber (inclui vendas a prazo) e contas a pagar. Despesas quitadas entram no lucro do dashboard.</p></div></section>
<div class="kpis">
  <div class="kpi"><span>A receber em aberto</span><strong class="ok"><?= money($openAr) ?></strong><small><?= money($lateAr) ?> em atraso</small></div>
  <div class="kpi"><span>A pagar em aberto</span><strong class="bad"><?= money($openAp) ?></strong><small><?= money($lateAp) ?> em atraso</small></div>
  <div class="kpi"><span>Saldo previsto</span><strong><?= money($openAr - $openAp) ?></strong></div>
</div>
<div class="cols" style="grid-template-columns:1fr 1fr">
  <div class="card"><h2>Contas a receber</h2>
    <form method="post" class="row c4" style="margin:12px 0"><?= App\Csrf::field() ?><input type="hidden" name="action" value="add_receivable">
      <input name="description" placeholder="Descricao" required style="grid-column:span 2"><input name="amount" inputmode="decimal" placeholder="Valor" required><input name="due_date" type="date" aria-label="Vencimento"><button class="btn green sm" type="submit" style="grid-column:span 4">Adicionar</button></form>
    <?php fin_table($ar, 'accounts_receivable', true); ?></div>
  <div class="card"><h2>Contas a pagar</h2>
    <form method="post" class="row c4" style="margin:12px 0"><?= App\Csrf::field() ?><input type="hidden" name="action" value="add_payable">
      <input name="description" placeholder="Descricao" required style="grid-column:span 2"><input name="amount" inputmode="decimal" placeholder="Valor" required><input name="due_date" type="date" aria-label="Vencimento"><input name="category" placeholder="Categoria (opcional)" style="grid-column:span 3"><button class="btn sm" type="submit">Adicionar</button></form>
    <?php fin_table($ap, 'accounts_payable', false); ?></div>
</div>

<?php
/**
 * Formulario de venda compartilhado entre PDV e PDV Mobile.
 * Espera: $mode ('pdv'|'mobile'), $sellers (lista), $fixedSeller (?array), $self (url base da pagina).
 */
use App\SaleService;

$old = $_SESSION['_old_sale'] ?? null;
unset($_SESSION['_old_sale']);
$token = $old['request_token'] ?? uuid4();
$lookupBase = $self . (str_contains($self, '?') ? '&' : '?') . 'lookup=';
?>
<form method="post" id="sale-form" data-lookup="<?= e($lookupBase) ?>" data-old="<?= e(json_encode($old, JSON_UNESCAPED_UNICODE) ?: 'null') ?>" novalidate>
  <?= App\Csrf::field() ?>
  <input type="hidden" name="action" value="sale">
  <input type="hidden" name="request_token" value="<?= e($token) ?>">

  <div class="card">
    <h2>Cliente</h2>
    <p class="sub">Busque um cliente existente ou preencha os dados para cadastrar na hora.</p>
    <div class="suggest" style="margin-bottom:10px">
      <input id="customer-search" placeholder="Buscar cliente por nome, telefone ou CPF/CNPJ" autocomplete="off">
      <ul id="customer-results" hidden></ul>
    </div>
    <input type="hidden" name="customer[customer_id]" id="customer_id">
    <div class="row c2"><input name="customer[first_name]" placeholder="Nome" autocomplete="off"><input name="customer[last_name]" placeholder="Sobrenome" autocomplete="off"></div>
    <div class="row"><input name="customer[email]" type="email" placeholder="E-mail (opcional)"></div>
    <div class="row c2"><input name="customer[phone]" inputmode="tel" placeholder="Telefone (xx xxxxx-xxxx)"><input name="customer[tax_id]" inputmode="numeric" placeholder="CPF/CNPJ"></div>
    <div class="row c2"><input name="customer[car]" placeholder="Carro"><input name="notes" placeholder="Observacoes"></div>

    <label class="flash ok" style="display:flex;gap:10px;align-items:center;cursor:pointer;margin:6px 0 10px">
      <input type="checkbox" name="wants_nfe" value="1" id="wants-nfe" style="width:auto"> NF-e
    </label>
    <fieldset style="border:1px solid var(--line);border-radius:16px;padding:14px;margin:0">
      <legend style="font-weight:700;padding:0 6px">Endereco do cliente</legend>
      <p class="small muted" style="margin:0 0 10px">Opcional em venda comum. Obrigatorio quando NF-e estiver marcada.</p>
      <div class="row c2"><input name="customer[street]" placeholder="Logradouro"><input name="customer[number]" placeholder="Numero"></div>
      <div class="row c2"><input name="customer[district]" placeholder="Bairro"><input name="customer[city]" placeholder="Cidade"></div>
      <div class="row c2"><input name="customer[state]" maxlength="2" placeholder="UF"><input name="customer[zip]" inputmode="numeric" placeholder="CEP"></div>
    </fieldset>
  </div>

  <div class="card">
    <?php if ($fixedSeller): ?>
      <input type="hidden" name="seller_id" value="<?= (int) $fixedSeller['id'] ?>">
      <p style="margin:0">Vendedor: <b><?= e($fixedSeller['name']) ?></b></p>
    <?php else: ?>
      <select name="seller_id" aria-label="Vendedor"><option value="">Selecione o vendedor</option>
        <?php foreach ($sellers as $s): ?><option value="<?= (int) $s['id'] ?>"><?= e($s['name']) ?></option><?php endforeach; ?></select>
    <?php endif; ?>
  </div>

  <div class="card">
    <div class="actions" style="justify-content:space-between;align-items:center">
      <div><h2>Itens da venda</h2></div>
      <button class="btn ghost sm" type="button" id="add-item">+ Item</button>
    </div>
    <div id="items" style="margin-top:12px"></div>
    <div class="totalbar"><span class="muted">Total da venda</span><b id="total">R$ 0,00</b></div>
  </div>

  <div class="card">
    <div class="actions" style="justify-content:space-between;align-items:center">
      <div><h2>Pagamento</h2><p class="sub" style="margin:0">Pode dividir em varios meios (ex.: pix + dinheiro). Na troca, descreva o item recebido: ele entra no estoque como usado.</p></div>
      <button class="btn ghost sm" type="button" id="add-payment">+ Pagamento</button>
    </div>
    <div id="payments" style="margin-top:12px"></div>
    <div class="sumbar">
      <div>Total<b id="s-total">R$ 0,00</b></div>
      <div>Pago<b id="s-paid">R$ 0,00</b></div>
      <div id="s-box">Falta<b id="s-diff">R$ 0,00</b></div>
    </div>
    <div id="due-box" hidden><label class="f" for="due_date">Vencimento da parte a prazo</label><input id="due_date" type="date" name="due_date"></div>
  </div>

  <button class="btn green block" type="submit" id="submit">Finalizar venda</button>
</form>
<script src="assets/sale.js"></script>

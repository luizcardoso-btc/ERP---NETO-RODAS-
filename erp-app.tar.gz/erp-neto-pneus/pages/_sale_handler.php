<?php
/** Processa o POST de venda (PDV e PDV Mobile). Espera $source ('pdv'|'mobile'), $fixedSeller e $self. */
use App\SaleService;

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || ($_POST['action'] ?? '') !== 'sale') {
    return;
}

$rows = fn ($k) => array_values(array_filter((array) ($_POST[$k] ?? []), 'is_array'));
$items = array_map(fn ($r) => [
    'product_id' => (int) ($r['product_id'] ?? 0) ?: null,
    'name' => (string) ($r['name'] ?? ''),
    'quantity' => (int) ($r['quantity'] ?? 0),
    'unit_price' => parse_money($r['unit_price'] ?? 0),
], $rows('items'));
$payments = array_map(fn ($r) => [
    'method' => (string) ($r['method'] ?? ''),
    'amount' => parse_money($r['amount'] ?? 0),
    'note' => (string) ($r['note'] ?? ''),
    'trade_qty' => (int) ($r['trade_qty'] ?? 1),
], $rows('payments'));

$data = [
    'request_token' => (string) ($_POST['request_token'] ?? ''),
    'seller_id' => $fixedSeller ? (int) $fixedSeller['id'] : ((int) ($_POST['seller_id'] ?? 0) ?: null),
    'wants_nfe' => !empty($_POST['wants_nfe']),
    'notes' => (string) ($_POST['notes'] ?? ''),
    'due_date' => (string) ($_POST['due_date'] ?? ''),
    'customer' => (array) ($_POST['customer'] ?? []),
    'items' => $items,
    'payments' => $payments,
];

try {
    $allowNeg = App\Env::get('ALLOW_NEGATIVE_STOCK', 'false') === 'true';
    $res = SaleService::create($data, $source, $allowNeg);
    flash('ok', $res['duplicate'] ? "Venda #{$res['id']} ja tinha sido registrada." : "Venda #{$res['id']} finalizada.");
} catch (DomainException $e) {
    $_SESSION['_old_sale'] = $_POST;
    flash('err', $e->getMessage());
}
redirect($self);

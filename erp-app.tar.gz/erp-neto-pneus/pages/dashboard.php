<?php
use App\Reports;

$month = preg_match('/^\d{4}-\d{2}$/', $_GET['m'] ?? '') ? $_GET['m'] : date('Y-m');
$s = Reports::summary($month);
$chart = Reports::daily($month);
$top = App\Database::all(
    "SELECT sel.name, COUNT(*) n, SUM(s.total) revenue FROM sales s JOIN sellers sel ON sel.id = s.seller_id
     WHERE DATE_FORMAT(s.created_at,'%Y-%m') = ? GROUP BY sel.id, sel.name ORDER BY revenue DESC",
    [$month]
);
$topProducts = App\Database::all(
    "SELECT i.description, SUM(i.quantity) qty, SUM(i.quantity*i.unit_price) revenue FROM sale_items i JOIN sales s ON s.id=i.sale_id
     WHERE DATE_FORMAT(s.created_at,'%Y-%m') = ? GROUP BY i.product_id, i.description ORDER BY qty DESC LIMIT 5",
    [$month]
);
$months = [];
for ($k = 0; $k < 12; $k++) {
    $months[] = date('Y-m', strtotime("first day of -$k month"));
}
?>
<section class="hero">
  <div>
    <div class="kicker">Inteligencia financeira</div>
    <h1>Dashboard financeiro e comercial</h1>
    <p>Faturamento, vendedores, custo estimado das mercadorias vendidas e lucro liquido considerando a folha semanal da equipe.</p>
    <form method="get" style="margin-top:14px;max-width:200px"><input type="hidden" name="page" value="dashboard">
      <select name="m" onchange="this.form.submit()" aria-label="Mes"><?php foreach ($months as $m): ?><option value="<?= $m ?>" <?= $m === $month ? 'selected' : '' ?>><?= date('m/Y', strtotime($m . '-01')) ?></option><?php endforeach; ?></select></form>
  </div>
  <div class="big"><small>Lucro liquido estimado no mes</small><strong><?= money($s['profit']) ?></strong><small>Margem liquida estimada: <?= number_format($s['margin'], 1, ',', '.') ?>%</small></div>
</section>

<div class="kpis">
  <div class="kpi"><span>Faturamento do mes</span><strong><?= money($s['revenue']) ?></strong><small><?= $s['sales'] ?> venda(s)</small></div>
  <div class="kpi"><span>Ticket medio</span><strong><?= money($s['ticket']) ?></strong><small>Base: mes selecionado</small></div>
  <div class="kpi"><span>CMV estimado</span><strong><?= money($s['cmv']) ?></strong><small>Custo cadastrado nos produtos vendidos</small></div>
  <div class="kpi"><span>Folha comercial estimada</span><strong><?= money($s['payroll']) ?></strong><small><?= money($s['weekly_payroll']) ?>/semana, proporcional aos dias do mes</small></div>
  <div class="kpi"><span>Despesas pagas</span><strong><?= money($s['expenses']) ?></strong><small>Contas a pagar quitadas no mes</small></div>
</div>

<div class="card">
  <div class="actions" style="justify-content:space-between;align-items:center">
    <div><h2>Faturamento, lucro liquido e vendedores</h2><p class="sub" style="margin:0">Clique nas legendas para exibir ou ocultar series do grafico.</p></div>
    <div class="chips" id="chips"></div>
  </div>
  <div class="chart-box" style="margin-top:14px"><canvas id="chart" aria-label="Grafico diario de faturamento e lucro" role="img"></canvas></div>
</div>

<div class="cols" style="grid-template-columns:1fr 1fr">
  <div class="card"><h2>Vendedores no mes</h2>
    <table><thead><tr><th>Vendedor</th><th class="num">Vendas</th><th class="num">Faturamento</th></tr></thead><tbody>
    <?php foreach ($top as $t): ?><tr><td><?= e($t['name']) ?></td><td class="num"><?= (int) $t['n'] ?></td><td class="num"><?= money($t['revenue']) ?></td></tr><?php endforeach; ?>
    <?php if (!$top): ?><tr><td colspan="3" class="muted">Sem vendas com vendedor neste mes.</td></tr><?php endif; ?></tbody></table></div>
  <div class="card"><h2>Mais vendidos</h2>
    <table><thead><tr><th>Produto</th><th class="num">Qtd.</th><th class="num">Valor</th></tr></thead><tbody>
    <?php foreach ($topProducts as $t): ?><tr><td><?= e($t['description']) ?></td><td class="num"><?= (int) $t['qty'] ?></td><td class="num"><?= money($t['revenue']) ?></td></tr><?php endforeach; ?>
    <?php if (!$topProducts): ?><tr><td colspan="3" class="muted">Sem vendas neste mes.</td></tr><?php endif; ?></tbody></table></div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
(function () {
  const d = <?= json_encode($chart, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG) ?>;
  const datasets = [
    { label: 'Faturamento', data: d.revenue, borderColor: '#16a34a', backgroundColor: 'rgba(22,163,74,.12)', fill: true, tension: .25 },
    { label: 'Lucro liquido', data: d.profit, borderColor: '#0f172a', borderDash: [6, 4], tension: .25 },
    ...d.sellers.map((s) => ({ label: s.name, data: s.data, borderColor: s.color, tension: .25 })),
  ];
  const chart = new Chart(document.getElementById('chart'), {
    type: 'line', data: { labels: d.labels, datasets },
    options: { maintainAspectRatio: false, interaction: { mode: 'index', intersect: false }, plugins: { legend: { display: false } },
      scales: { y: { ticks: { callback: (v) => 'R$ ' + v.toLocaleString('pt-BR') } } } },
  });
  const box = document.getElementById('chips');
  datasets.forEach((ds, i) => {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'chip'; b.textContent = ds.label; b.style.background = ds.borderColor;
    b.onclick = () => { chart.setDatasetVisibility(i, !chart.isDatasetVisible(i)); b.classList.toggle('off', !chart.isDatasetVisible(i)); chart.update(); };
    box.appendChild(b);
  });
})();
</script>

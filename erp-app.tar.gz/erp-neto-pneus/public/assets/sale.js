(function () {
  'use strict';
  const form = document.getElementById('sale-form');
  if (!form) return;

  const lookupBase = form.dataset.lookup;
  const itemsBox = document.getElementById('items');
  const paysBox = document.getElementById('payments');
  const brl = (c) => (c / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const cents = (v) => {
    v = String(v || '').trim().replace(/[^\d,.\-]/g, '');
    if (v.includes(',')) v = v.replace(/\./g, '').replace(',', '.');
    const n = parseFloat(v);
    return isNaN(n) ? 0 : Math.round(n * 100);
  };
  const el = (html) => { const t = document.createElement('template'); t.innerHTML = html.trim(); return t.content.firstChild; };
  const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  let seq = 0;

  function debounce(fn, ms) { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; }

  async function search(kind, q) {
    const r = await fetch(lookupBase + kind + '&q=' + encodeURIComponent(q), { credentials: 'same-origin' });
    return r.ok ? r.json() : [];
  }

  /* ---------- itens ---------- */
  function addItem(data = {}) {
    const i = seq++;
    const line = el(`
      <div class="item-line">
        <div class="grid">
          <div class="suggest">
            <input name="items[${i}][name]" placeholder="Buscar produto ou digitar novo produto" autocomplete="off" value="${esc(data.name)}">
            <input type="hidden" name="items[${i}][product_id]" value="${esc(data.product_id)}">
            <ul hidden></ul>
          </div>
          <input name="items[${i}][quantity]" type="number" min="1" inputmode="numeric" placeholder="Quantidade" value="${esc(data.quantity)}">
          <input name="items[${i}][unit_price]" inputmode="decimal" placeholder="Preco unitario" value="${esc(data.unit_price)}">
        </div>
        <div class="line-foot"><span class="small muted stock-info"></span><button type="button" class="rm" style="color:var(--danger)">Remover item</button></div>
      </div>`);
    const [name, pid] = line.querySelectorAll('.suggest input');
    const list = line.querySelector('ul');
    const info = line.querySelector('.stock-info');
    const qty = line.querySelector('[name$="[quantity]"]');
    const price = line.querySelector('[name$="[unit_price]"]');

    name.addEventListener('input', debounce(async () => {
      pid.value = ''; info.textContent = '';
      const rows = await search('product', name.value);
      list.innerHTML = rows.map((p, k) =>
        `<li data-k="${k}">${esc(p.name)} <small>${p.condition_type === 'usado' ? 'usado · ' : ''}estoque ${p.stock} · ${brl(Math.round(p.price * 100))}</small></li>`).join('');
      list.hidden = !rows.length;
      list.onclick = (ev) => {
        const li = ev.target.closest('li'); if (!li) return;
        const p = rows[+li.dataset.k];
        name.value = p.name; pid.value = p.id;
        price.value = Number(p.price).toFixed(2).replace('.', ',');
        if (!qty.value) qty.value = 1;
        info.textContent = 'Em estoque: ' + p.stock + (p.location ? ' · ' + p.location : '');
        list.hidden = true; recalc();
      };
    }, 200));
    name.addEventListener('blur', () => setTimeout(() => (list.hidden = true), 150));
    line.querySelector('.rm').onclick = () => { line.remove(); if (!itemsBox.children.length) addItem(); recalc(); };
    line.addEventListener('input', recalc);
    itemsBox.appendChild(line);
  }

  /* ---------- pagamentos ---------- */
  function addPayment(data = {}) {
    const i = seq++;
    const sel = (m) => (data.method === m ? 'selected' : '');
    const line = el(`
      <div class="pay-line">
        <div class="grid">
          <select name="payments[${i}][method]" aria-label="Forma de pagamento">
            <option value="dinheiro" ${sel('dinheiro')}>Dinheiro</option><option value="pix" ${sel('pix')}>Pix</option>
            <option value="cartao" ${sel('cartao')}>Cartao</option><option value="prazo" ${sel('prazo')}>A prazo</option>
            <option value="troca" ${sel('troca')}>Troca</option>
          </select>
          <input name="payments[${i}][amount]" inputmode="decimal" placeholder="Valor" value="${esc(data.amount)}">
        </div>
        <div class="trade" hidden style="margin-top:10px">
          <div class="grid"><input name="payments[${i}][note]" placeholder="Item recebido (ex.: 4 pneus 175/70 R14 usados)" value="${esc(data.note)}">
          <input name="payments[${i}][trade_qty]" type="number" min="1" placeholder="Qtd. recebida" value="${esc(data.trade_qty || 1)}"></div>
        </div>
        <div class="line-foot"><button type="button" class="rest" style="color:var(--brand-d)">= restante</button><button type="button" class="rm" style="color:var(--danger)">Remover</button></div>
      </div>`);
    const method = line.querySelector('select');
    const amount = line.querySelector('[name$="[amount]"]');
    const trade = line.querySelector('.trade');
    const sync = () => { trade.hidden = method.value !== 'troca'; recalc(); };
    method.onchange = sync;
    line.querySelector('.rest').onclick = () => {
      const diff = totals().total - totals().paid + cents(amount.value);
      amount.value = diff > 0 ? (diff / 100).toFixed(2).replace('.', ',') : '';
      recalc();
    };
    line.querySelector('.rm').onclick = () => { line.remove(); if (!paysBox.children.length) addPayment(); recalc(); };
    line.addEventListener('input', recalc);
    paysBox.appendChild(line);
    sync();
  }

  /* ---------- totais ---------- */
  function totals() {
    let total = 0;
    itemsBox.querySelectorAll('.item-line').forEach((l) => {
      total += cents(l.querySelector('[name$="[unit_price]"]').value) * (parseInt(l.querySelector('[name$="[quantity]"]').value, 10) || 0);
    });
    let paid = 0, prazo = false;
    paysBox.querySelectorAll('.pay-line').forEach((l) => {
      paid += cents(l.querySelector('[name$="[amount]"]').value);
      if (l.querySelector('select').value === 'prazo') prazo = true;
    });
    return { total, paid, prazo };
  }
  function recalc() {
    const t = totals();
    document.getElementById('total').textContent = brl(t.total);
    document.getElementById('s-total').textContent = brl(t.total);
    document.getElementById('s-paid').textContent = brl(t.paid);
    const diff = t.total - t.paid;
    const box = document.getElementById('s-box');
    box.className = diff === 0 && t.total > 0 ? 'ok' : 'miss';
    box.firstChild.textContent = diff < 0 ? 'Excedente' : (diff === 0 && t.total > 0 ? 'Fechado' : 'Falta');
    document.getElementById('s-diff').textContent = diff === 0 && t.total > 0 ? 'OK' : brl(Math.abs(diff));
    document.getElementById('due-box').hidden = !t.prazo;
  }

  /* ---------- cliente ---------- */
  const cs = document.getElementById('customer-search');
  const cr = document.getElementById('customer-results');
  cs.addEventListener('input', debounce(async () => {
    const rows = await search('customer', cs.value);
    cr.innerHTML = rows.map((c, k) => `<li data-k="${k}">${esc(c.first_name + ' ' + c.last_name)} <small>${esc(c.phone || '')} ${esc(c.car || '')}</small></li>`).join('');
    cr.hidden = !rows.length;
    cr.onclick = (ev) => {
      const li = ev.target.closest('li'); if (!li) return;
      const c = rows[+li.dataset.k];
      document.getElementById('customer_id').value = c.id;
      ['first_name', 'last_name', 'email', 'phone', 'tax_id', 'car', 'street', 'number', 'district', 'city', 'state', 'zip']
        .forEach((f) => { const i = form.querySelector(`[name="customer[${f}]"]`); if (i) i.value = c[f] || ''; });
      cs.value = c.first_name + ' ' + c.last_name; cr.hidden = true;
    };
  }, 250));
  cs.addEventListener('blur', () => setTimeout(() => (cr.hidden = true), 150));
  // Editar manualmente o nome desfaz o vinculo com o cliente buscado.
  form.querySelector('[name="customer[first_name]"]').addEventListener('input', () => (document.getElementById('customer_id').value = ''));

  /* ---------- NF-e ---------- */
  const nfe = document.getElementById('wants-nfe');
  nfe.addEventListener('change', () => {
    ['tax_id', 'street', 'number', 'district', 'city', 'state', 'zip', 'first_name'].forEach((f) => {
      form.querySelector(`[name="customer[${f}]"]`).required = nfe.checked;
    });
  });

  form.addEventListener('submit', (ev) => {
    const t = totals();
    if (!t.total) { ev.preventDefault(); alert('Adicione ao menos um item com quantidade e preco.'); return; }
    if (t.total !== t.paid) { ev.preventDefault(); alert('Os pagamentos precisam fechar com o total da venda.'); return; }
    if (nfe.checked && !form.checkValidity()) { ev.preventDefault(); form.reportValidity(); return; }
    document.getElementById('submit').disabled = true; // evita duplo clique
  });

  /* ---------- restaurar apos erro ---------- */
  let old = null;
  try { old = JSON.parse(form.dataset.old); } catch (e) { /* sem dados anteriores */ }
  if (old) {
    const set = (n, v) => { const i = form.querySelector(`[name="${n}"]`); if (i && v != null) i.value = v; };
    Object.entries(old.customer || {}).forEach(([k, v]) => set(`customer[${k}]`, v));
    set('notes', old.notes); set('seller_id', old.seller_id); set('due_date', old.due_date);
    if (old.wants_nfe) { nfe.checked = true; nfe.dispatchEvent(new Event('change')); }
    Object.values(old.items || {}).forEach(addItem);
    Object.values(old.payments || {}).forEach(addPayment);
  }
  if (!itemsBox.children.length) addItem();
  if (!paysBox.children.length) addPayment();
  document.getElementById('add-item').onclick = () => addItem();
  document.getElementById('add-payment').onclick = () => addPayment();
  recalc();
})();
